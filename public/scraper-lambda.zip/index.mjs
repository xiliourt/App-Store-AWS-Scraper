import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';
import { fileURLToPath } from 'node:url';
import os from 'node:os';
import { countryData, filterHighestPriceProducts, groupProducts } from './lib/utils.mjs';
import { getProducts } from './lib/scraper.mjs';

const __filename = fileURLToPath(import.meta.url);

// --- 1. WORKER LOGIC ---
// This block runs ONLY when the file is spawned as a worker thread.
if (!isMainThread) {
  const { countries, appId } = workerData;

  (async () => {
    const workerResults = [];
    
    // Process the chunk of countries assigned to this worker
    await Promise.all(countries.map(async (country) => {
      try {
        const products = await getProducts(country.countryCode, appId);
        for (const product of products) {
          workerResults.push({
            ...product,
            countryCode: country.countryCode,
            countryName: country.countryName,
            currency: country.currency,
          });
        }
      } catch (error) {
        console.error(`Worker failed for ${country.countryName}:`, error);
      }
    }));

    // Send results back to main thread
    parentPort.postMessage(workerResults);
  })();
}

// --- 2. MAIN THREAD (LAMBDA HANDLER) ---
// This function is exported for Lambda, but we only run the logic inside if we are NOT a worker.
export const handler = async (event) => {
  // If this file is running as a worker, we don't want to execute the handler logic.
  // Although the handler function exists, it won't be called by the Worker runtime.
  
  const appId = event.queryStringParameters?.appId;

  if (!appId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'appId is required' }),
    };
  }

  // Determine thread count based on available CPUs (min 1, max 4 for safety)
  // Note: Standard Lambdas (128mb) have 1 vCPU. You need ~1.8GB memory to get 2+ vCPUs.
  const cpuCount = os.cpus().length || 1;
  const threadCount = Math.min(countryData.length, Math.max(cpuCount, 1));
  
  const chunkSize = Math.ceil(countryData.length / threadCount);
  const chunks = [];
  for (let i = 0; i < countryData.length; i += chunkSize) {
    chunks.push(countryData.slice(i, i + chunkSize));
  }

  try {
    const results = await Promise.all(chunks.map(chunk => {
      return new Promise((resolve, reject) => {
        const worker = new Worker(__filename, {
          workerData: { countries: chunk, appId }
        });
        
        worker.on('message', resolve);
        worker.on('error', reject);
        worker.on('exit', (code) => {
          if (code !== 0) reject(new Error(`Worker stopped with exit code ${code}`));
        });
      });
    }));

    const allProducts = results.flat();
    const filteredProducts = filterHighestPriceProducts(allProducts);
    const groupedData = groupProducts(filteredProducts);

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*", // Required for CORS to work on the actual request
        "Access-Control-Allow-Credentials": true // Required for cookies, authorization headers
      },
      body: groupedData,
    };

  } catch (error) {
    console.error('Scraping failed:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal Server Error', error: error.message }),
    };
  }
};